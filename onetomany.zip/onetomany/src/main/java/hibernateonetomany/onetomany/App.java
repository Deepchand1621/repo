package hibernateonetomany.onetomany;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;

import hibernate.dao.CustomerDao;
import hibernate.dao.LoanDao;
import hibernate.entity.Customers;
import hibernate.entity.Loan;
import hibernate.util.HibernateUtil;

public class App 
{
    public static void main( String[] args )
    {
    	CustomerDao dao= new CustomerDao();
    	LoanDao da= new LoanDao();
       Customers c= new Customers("Deepchandu","Peruru");
       Loan l1= new Loan("personalloan","Engineer",50000,"Anantapur");
       Loan l2= new Loan("Goldloan","Engineer",50000,"Anantapur");
       Loan l3= new Loan("Homeloan","Engineer",50000,"Anantapur");
       List<Loan>loan= new ArrayList();
      loan.add(l1);
      loan.add(l2);
      loan.add(l3);
      c.setLoan(loan);
      dao.saveCustomer(c);
     dao.displayCustomers();
    }
}
