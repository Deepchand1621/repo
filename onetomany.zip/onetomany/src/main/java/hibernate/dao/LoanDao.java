package hibernate.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import hibernate.entity.Customers;
import hibernate.entity.Loan;
import hibernate.util.HibernateUtil;




public class LoanDao {
	
	public void saveCustomer(Loan c){
		Transaction transaction=null;
		try(Session session=HibernateUtil.getSessionFactory().openSession()){
			System.out.println("saving the customer");
			transaction=session.beginTransaction();
			
			session.save(c);
			session.getTransaction().commit();
			System.out.println("saved");
			
		}
		catch(Exception e){
			System.out.println("problem1 occured");
			if(transaction!=null){
			transaction.rollback();}
			e.printStackTrace();
		}
		
	}
	//displayall
	public void displayCustomers(){
		List<Loan> custList=fetchCustomers();
		for(Loan cust:custList)
		{
			System.out.println(cust.toString());
		}
		
	}
	
	public List<Loan> fetchCustomers(){
		System.out.println("Fetching Customers");
		Session session=HibernateUtil.getSessionFactory().openSession();
		
	Query query=session.createQuery("from Loan",Loan.class);
List<Loan> cust=	query.getResultList();
		System.out.println("Fetched "+cust.size());
		return cust;
	}

	//update
	public void update(Loan c){
		Transaction transaction=null;
		try(Session session=HibernateUtil.getSessionFactory().openSession()){
			System.out.println("updating");
			transaction=session.beginTransaction();
			session.update(c);
			session.getTransaction().commit();
			System.out.println("Updated");
			
		}
		catch(Exception e){
			System.out.println("problem2 occured");
			if(transaction!=null){
			transaction.rollback();}
			e.printStackTrace();
		}
		
	}
	
	//delete
	public void delete (int id)
	{
		Transaction transaction=null;
		try(Session session=HibernateUtil.getSessionFactory().openSession()){
			System.out.println("Deleting");
			transaction=session.beginTransaction();
		Loan cc=	session.get(Loan.class, id);
		session.delete(cc);
			session.getTransaction().commit();
			System.out.println("deleted");
			
		}
		catch(Exception e){
			System.out.println("problem3 occured");
			if(transaction!=null){
			transaction.rollback();}
			e.printStackTrace();
		}
		
	}
	//fetchbyid
	public void fetchByCustomerId(Integer id)
	{
		System.out.println("Fetching Customerdetails from customer");
		Session session=HibernateUtil.getSessionFactory().openSession();
		Loan cust=session.load(Loan.class, id);
		System.out.println(cust.toString());

		session.close();
		
	}

}
