package hibernate.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;



import hibernate.entity.Customers;
import hibernate.util.HibernateUtil;


public class CustomerDao {

	
	public void saveCustomer(Customers c){
		Transaction transaction=null;
		try(Session session=HibernateUtil.getSessionFactory().openSession()){
			System.out.println("saving the customer");
			transaction=session.beginTransaction();
			
			session.save(c);
			session.getTransaction().commit();
			System.out.println("saved");
			
		}
		catch(Exception e){
			System.out.println("problem1 occured");
			if(transaction!=null){
			transaction.rollback();}
			e.printStackTrace();
		}
		
	}
	
	//displayAll
	public void displayCustomers(){
		List<Customers> custList=fetchCustomers();
		for(Customers cust:custList)
		{
			System.out.println(cust.toString());
		}
		
	}
	
	public List<Customers> fetchCustomers(){
		System.out.println("Fetching Customers");
		Session session=HibernateUtil.getSessionFactory().openSession();
		
	Query query=session.createQuery("from Customers",Customers.class);
List<Customers> cust=	query.getResultList();
		System.out.println("Fetched "+cust.size());
		return cust;
	}
	
	public void update(Customers c){
		Transaction transaction=null;
		try(Session session=HibernateUtil.getSessionFactory().openSession()){
			System.out.println("updating");
			transaction=session.beginTransaction();
			session.update(c);
			session.getTransaction().commit();
			System.out.println("Updated");
			
		}
		catch(Exception e){
			System.out.println("problem2 occured");
			if(transaction!=null){
			transaction.rollback();}
			e.printStackTrace();
		}
		
	}
	
	//delete
	public void delete (int id)
	{
		Transaction transaction=null;
		try(Session session=HibernateUtil.getSessionFactory().openSession()){
			System.out.println("Deleting");
			transaction=session.beginTransaction();
		Customers cc=	session.get(Customers.class, id);
		session.delete(cc);
			session.getTransaction().commit();
			System.out.println("deleted");
			
		}
		catch(Exception e){
			System.out.println("problem3 occured");
			if(transaction!=null){
			transaction.rollback();}
			e.printStackTrace();
		}
		
	}
	//fetchbyid
	public void fetchByCustomerId(Integer id)
	{
		System.out.println("Fetching Customerdetails from customer");
		Session session=HibernateUtil.getSessionFactory().openSession();
		Customers cust=session.load(Customers.class, id);
		System.out.println(cust.toString());

		session.close();
		
	}
}
