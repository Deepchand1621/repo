package hibernate.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import hibernate.entity.Customers;
import hibernate.entity.Loan;



public class HibernateUtil {
static SessionFactory sessionFactory=null;
	
	public static SessionFactory getSessionFactory(){
		if(sessionFactory==null)
		{
			Configuration c=new Configuration().addAnnotatedClass(Customers.class).addAnnotatedClass(Loan.class).configure("hibernate.cfg.xml");
			
			 sessionFactory=c.buildSessionFactory();
			
		}
		
		return sessionFactory;
	}
}
