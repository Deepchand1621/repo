package hibernate.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Loan")
public class Loan {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private int id;
	
	@Column(name="Loan_Type")
	private String loanType;
	
	@Column(name="Designation")
	private String designation;
	
	@Column(name="Loan_Amount")
	private int loanAmount;
	
	@Column(name="Location")
	private String location;

	public Loan(String loanType, String designation, int loanAmount, String location) {
		super();
		this.loanType = loanType;
		this.designation = designation;
		this.loanAmount = loanAmount;
		this.location = location;
	}

	public Loan() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public int getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(int loanAmount) {
		this.loanAmount = loanAmount;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "Loan [id=" + id + ", loanType=" + loanType + ", designation=" + designation + ", loanAmount="
				+ loanAmount + ", location=" + location + "]";
	}
	
	
}
