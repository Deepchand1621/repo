package com.hibernateonetoone.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hibernateonetoone.entity.Customer;
import com.hibernateonetoone.entity.CustomerDetails;



public class HibernateUtil {
static SessionFactory sessionFactory=null;
	
	public static SessionFactory getSessionFactory(){
		if(sessionFactory==null)
		{
			Configuration c=new Configuration().addAnnotatedClass(Customer.class).addAnnotatedClass(CustomerDetails.class).configure("hibernate.cfg.xml");
			
			 sessionFactory=c.buildSessionFactory();
			
		}
		
		return sessionFactory;
	}
}
