package com.hibernateonetoone.dao;



import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hibernateonetoone.entity.Customer;
import com.hibernateonetoone.util.HibernateUtil;

public class CustomerDao {
	
	//displayAll
		public void displayCustomers(){
			List<Customer> custList=fetchCustomers();
			for(Customer cust:custList)
			{
				System.out.println(cust.toString());
			}
			
		}
		
		public List<Customer> fetchCustomers(){
			System.out.println("Fetching Customers");
			Session session=HibernateUtil.getSessionFactory().openSession();
			
		Query query=session.createQuery("from Customer",Customer.class);
	List<Customer> cust=	query.getResultList();
			System.out.println("Fetched "+cust.size());
			return cust;
		}
	
	
	//save customer
	public void saveCustomer(Customer c){
		Transaction transaction=null;
		try(Session session=HibernateUtil.getSessionFactory().openSession()){
			System.out.println("saving the customer");
			transaction=session.beginTransaction();
			session.save(c.getCustdetails());
			session.save(c);
			session.getTransaction().commit();
			System.out.println("saved");
			
		}
		catch(Exception e){
			System.out.println("problem1 occured");
			if(transaction!=null){
			transaction.rollback();}
			e.printStackTrace();
		}
		
	}
	
	
	//update
	public void update(Customer c){
		Transaction transaction=null;
		try(Session session=HibernateUtil.getSessionFactory().openSession()){
			System.out.println("updating");
			transaction=session.beginTransaction();
			session.update(c);
			session.getTransaction().commit();
			System.out.println("Updated");
			
		}
		catch(Exception e){
			System.out.println("problem2 occured");
			if(transaction!=null){
			transaction.rollback();}
			e.printStackTrace();
		}
		
	}
	
	//delete
	public void delete (int id)
	{
		Transaction transaction=null;
		try(Session session=HibernateUtil.getSessionFactory().openSession()){
			System.out.println("Deleting");
			transaction=session.beginTransaction();
		Customer cc=	session.get(Customer.class, id);
		session.delete(cc);
			session.getTransaction().commit();
			System.out.println("deleted");
			
		}
		catch(Exception e){
			System.out.println("problem3 occured");
			if(transaction!=null){
			transaction.rollback();}
			e.printStackTrace();
		}
		
	}
}
