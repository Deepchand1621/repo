package com.lvu2code.springhibernate.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lvu2code.springhibernate.Entity.Customers;
import com.lvu2code.springhibernate.Service.CustomerService;

@Controller

public class CustomerController {

	@Autowired
	private CustomerService customerService;
	
	//add the customer into the database
	
	@GetMapping(value="/showFormForAdd")
	public ModelAndView showFormForAdd(){
		
		ModelAndView mv= new ModelAndView("register");
		Customers customer= new Customers();
		mv.addObject("customer",customer);
		return mv;
	}
	
	
	//saving the customer into the database
	@GetMapping(value="/saveCustomer")
	public ModelAndView saveCustomer(@ModelAttribute("customer") Customers customer){
		
		customerService.saveCustomer(customer);
		return new ModelAndView("register");
		
	}
	
	//getting the list of all customers
	@GetMapping("/listCustomers")
	public ModelAndView listCustomers(){
		
		ModelAndView mv= new ModelAndView("listform");
		List<Customers> customers = customerService.getCustomers();
		mv.addObject("customers", customers);
		return mv;
		
	}
	
	//show form for updation
	@GetMapping("/showFormForUpdate")
	public ModelAndView showFormForUpdate(@RequestParam("id") int id){
		
		ModelAndView mv= new ModelAndView("register");
		Customers customer=customerService.getCustomer(id);
		mv.addObject("customer",customer);
		return mv;
	}
	
	
	//delete the customer
	@GetMapping("/showFormForDelete")
	public String showFormForDelete(@RequestParam("id") int id){
		
	
	customerService.deleteCustomer(id);
	return "redirect:/listCustomers";
	}
	
	
	//searching
	@GetMapping("/showFormForSearching")
	public ModelAndView showFormForSearching(){
		ModelAndView mv= new ModelAndView("searchform");
		
		return mv;
		
	}
	
	
	
	//search for a customer
	@GetMapping("/showFormForSearch")
	public ModelAndView showFormForSearch(@RequestParam("id") String id){
		int id1=Integer.parseInt(id);
		ModelAndView mv = new ModelAndView("searchform");
		Customers customers=customerService.getCustomer(id1);
		mv.addObject("customers", customers);
		return mv;
	}
}
