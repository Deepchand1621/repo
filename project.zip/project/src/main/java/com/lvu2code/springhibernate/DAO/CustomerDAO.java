package com.lvu2code.springhibernate.DAO;

import java.util.List;

import com.lvu2code.springhibernate.Entity.Customers;

public interface CustomerDAO {

	public void saveCustomer(Customers customer);

	public List<Customers> getCustomers();

	public Customers getCustomer(int id);

	public void deleteCustomer(int id);

	

}
