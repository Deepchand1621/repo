package com.lvu2code.springhibernate.DAO;

import java.util.List;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lvu2code.springhibernate.Entity.Customers;

@Repository
public class CustomerDAOImpl implements CustomerDAO {
	
	@Autowired
	private SessionFactory sessionFactory;

	public void saveCustomer(Customers customer) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession();
		session.saveOrUpdate(customer);
		
	}

	public List<Customers> getCustomers() {
		// TODO Auto-generated method stub
		
		Session currentSession=	sessionFactory.getCurrentSession();
		Query<Customers>theQuery=currentSession.createQuery("from Customers",Customers.class);
		List<Customers>customers=theQuery.getResultList();
		return customers;
	}

	public Customers getCustomer(int id) {
		// TODO Auto-generated method stub
		
		Session currentSession=	sessionFactory.getCurrentSession();
		Customers theCustomer=currentSession.get(Customers.class,id);
		return theCustomer ;
	}

	public void deleteCustomer(int id) {
		// TODO Auto-generated method stub
		
		Session currentSession=	sessionFactory.getCurrentSession();
		Customers theCustomer=currentSession.get(Customers.class,id);
		currentSession.delete(theCustomer);
		
	}

	

}
