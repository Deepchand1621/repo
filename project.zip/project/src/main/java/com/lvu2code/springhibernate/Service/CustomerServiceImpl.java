package com.lvu2code.springhibernate.Service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lvu2code.springhibernate.DAO.CustomerDAO;
import com.lvu2code.springhibernate.Entity.Customers;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerDAO customerDAO;

	@Transactional
	public void saveCustomer(Customers customer) {
		// TODO Auto-generated method stub
		customerDAO.saveCustomer(customer);
	}

	@Transactional
	public List<Customers> getCustomers() {
		// TODO Auto-generated method stub
		return customerDAO.getCustomers();
	}

	@Transactional
	public Customers getCustomer(int id) {
		// TODO Auto-generated method stub
		return customerDAO.getCustomer(id);
	}
	@Transactional
	public void deleteCustomer(int id) {
		// TODO Auto-generated method stub
		customerDAO.deleteCustomer(id);
	}

	

}
