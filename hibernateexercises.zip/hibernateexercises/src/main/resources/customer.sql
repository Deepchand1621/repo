create table cust100(ID int not null auto_increment,First_Name varchar(64),Last_Name varchar(64),
Age int ,Designation varchar(64),Location varchar(64));