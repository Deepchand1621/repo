package com.hibernatecrud.app;

import com.hibernatecrud.dao.CustomerDao;
import com.hibernatecrud.entity.Customer;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
CustomerDao dao= new CustomerDao();
Customer c= new Customer("Deepu","chandu",23,"Engineer","Anantapur");
//dao.createCustomer(c);//working
dao.displayCustomers();//not
//dao.fetchById(4);//working
//dao.update(4);//not
//dao.deleteCustomer(3);//working
	}

}
