package com.hibernatecrud.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.hibernatecrud.entity.Customer;
import com.hibernatecrud.util.HibernateUtil;

public class CustomerDao {
	
	static SessionFactory sessionFactory=null;
	
	public void createCustomer(Customer c){
		
		System.out.println("creating customer");
		Session session=HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		session.save(c);
		session.getTransaction().commit();
		System.out.println("customer created successfully "+c.toString());
		
	}
	
	//displayAll
	public void displayCustomers(){
		List<Customer> custList=fetchCustomers();
		for(Customer cust:custList)
		{
			System.out.println(cust.toString());
		}
		
	}
	
	
//fetchning all
	public List<Customer> fetchCustomers(){
		System.out.println("Fetching Customers");
		Session session=HibernateUtil.getSessionFactory().openSession();
		
	List<Customer>	cust=session.createQuery("from cust100",Customer.class).list();
		session.close();
		System.out.println("Fetched "+cust.size());
		return cust;
	}
	
	//fetch by id
	public Customer fetchById(Integer id)
	{
		System.out.println("Fetching Customer");
		Session session=HibernateUtil.getSessionFactory().openSession();
		Customer cust=session.load(Customer.class, id);
		System.out.println(cust.toString());
		session.close();
		return cust;
	}
	
	//update
	public void update(int id)
	{
		System.out.println("Updating Customer");
		Session session=HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		Customer cc=session.load(Customer.class, id);
    	cc.setFirstName(cc.getFirstName()+"change");
		cc.setAge(cc.getAge()+2);
		System.out.println(cc.toString());
		session.getTransaction().commit();
		session.close();
		System.out.println("Updated");
	}
	
	//delete
	public void deleteCustomer(Integer id){
		System.out.println("delete customer");
		Customer c=fetchById(id);
		Session session=HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		session.delete(c);
		session.getTransaction().commit();
		session.close();
		System.out.println("deleted successfully");
		
		
	}
	
	//delete all
	public void deleteAll(){
		Session session=HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
	Query query=	session.createQuery("Delete from cust100");
	query.executeUpdate();
	session.getTransaction().commit();
	session.close();
	System.out.println("deleted all customers data from database");
	
	}
}
