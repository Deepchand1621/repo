package com.hibernateonetoone.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="customerdetails")
public class CustomerDetails {
	
	
	@Column(name="ID")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Id
	private int detailsId;
	
	@Column(name="Age")
	private int age;
	
	@Column(name="Email")
	private String email;
	
	
	@Column(name="Designation")
	private String designation;
	
	
	@Column(name="Salary")
	private int salary;
	
	@Column(name="Location")
	private String location;
	
	@OneToOne(mappedBy="custdetails",cascade=CascadeType.ALL)
	private Customer cust;
	
	

	public CustomerDetails( int age, String email, String designation, int salary, String location) {
		super();
		
		this.age = age;
		this.email = email;
		this.designation = designation;
		this.salary = salary;
		this.location = location;
	}

	
	
	public Customer getCust() {
		return cust;
	}



	public void setCust(Customer cust) {
		this.cust = cust;
	}



	public CustomerDetails() {
		super();
	}



	public int getDetailsId() {
		return detailsId;
	}

	public void setDetailsId(int detailsId) {
		this.detailsId = detailsId;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}



	@Override
	public String toString() {
		return "CustomerDetails [detailsId=" + detailsId + ", age=" + age + ", email=" + email + ", designation="
				+ designation + ", salary=" + salary + ", location=" + location + ", cust=" + cust + "]";
	}



	
	
	

}
