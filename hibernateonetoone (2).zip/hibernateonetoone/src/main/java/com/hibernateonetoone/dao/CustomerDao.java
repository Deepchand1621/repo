package com.hibernateonetoone.dao;



import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hibernateonetoone.entity.Customer;
import com.hibernateonetoone.entity.CustomerDetails;
import com.hibernateonetoone.util.HibernateUtil;

public class CustomerDao {
	
	//displayAll
	public void displayCustomersDetails(){
		List<CustomerDetails> custList=fetchCustomersDetails();
		for(CustomerDetails cust:custList)
		{
			System.out.println(cust.toString());
		}
		
	}
	
	public List<CustomerDetails> fetchCustomersDetails(){
		System.out.println("Fetching Customers");
		Session session=HibernateUtil.getSessionFactory().openSession();
		
	Query query=session.createQuery("from CustomerDetails",CustomerDetails.class);
List<CustomerDetails> cust=	query.getResultList();
		System.out.println("Fetched "+cust.size());
		return cust;
	}
	
		//displayAll
				public void displayCustomers(){
					List<Customer> custList=fetchCustomers();
					for(Customer cust:custList)
					{
						System.out.println(cust.toString());
					}
					
				}
				
				public List<Customer> fetchCustomers(){
					System.out.println("Fetching Customers");
					Session session=HibernateUtil.getSessionFactory().openSession();
					
				Query query=session.createQuery("from Customer",Customer.class);
			List<Customer> cust=	query.getResultList();
					System.out.println("Fetched "+cust.size());
					return cust;
				}
	
	//save customer
	public void saveCustomer(Customer c){
		Transaction transaction=null;
		try(Session session=HibernateUtil.getSessionFactory().openSession()){
			System.out.println("saving the customer");
			transaction=session.beginTransaction();
			session.save(c.getCustdetails());
			session.save(c);
			session.getTransaction().commit();
			System.out.println("saved");
			
		}
		catch(Exception e){
			System.out.println("problem1 occured");
			if(transaction!=null){
			transaction.rollback();}
			e.printStackTrace();
		}
		
	}
	
	//save customerDetails
		public void saveCustomerDetails(CustomerDetails c){
			Transaction transaction=null;
			try(Session session=HibernateUtil.getSessionFactory().openSession()){
				System.out.println("saving the customerDetails");
				transaction=session.beginTransaction();
				session.save(c.getCust());
				session.save(c);
				session.getTransaction().commit();
				System.out.println("saved");
				
			}
			catch(Exception e){
				System.out.println("problem1 occured");
				if(transaction!=null){
				transaction.rollback();}
				e.printStackTrace();
			}
			
		}
	
	
	//update
	public void update(Customer c){
		Transaction transaction=null;
		try(Session session=HibernateUtil.getSessionFactory().openSession()){
			System.out.println("updating");
			transaction=session.beginTransaction();
			session.update(c);
			session.getTransaction().commit();
			System.out.println("Updated");
			
		}
		catch(Exception e){
			System.out.println("problem2 occured");
			if(transaction!=null){
			transaction.rollback();}
			e.printStackTrace();
		}
		
	}
	
	//delete
	public void delete (int id)
	{
		Transaction transaction=null;
		try(Session session=HibernateUtil.getSessionFactory().openSession()){
			System.out.println("Deleting");
			transaction=session.beginTransaction();
		CustomerDetails cc=	session.get(CustomerDetails.class, id);
		session.delete(cc);
			session.getTransaction().commit();
			System.out.println("deleted");
			
		}
		catch(Exception e){
			System.out.println("problem3 occured");
			if(transaction!=null){
			transaction.rollback();}
			e.printStackTrace();
		}
		
	}
	//fetch by id
	public CustomerDetails fetchById(Integer id)
	{
		System.out.println("Fetching Customer from customerDetails");
		Session session=HibernateUtil.getSessionFactory().openSession();
		CustomerDetails cust=session.load(CustomerDetails.class, id);
		System.out.print(cust.toString());
	System.out.print(cust.getCust().toString());
		session.close();
		return cust;
	}
	
	public Customer fetchByCustomerId(Integer id)
	{
		System.out.println("Fetching Customerdetails from customer");
		Session session=HibernateUtil.getSessionFactory().openSession();
		Customer cust=session.load(Customer.class, id);
		System.out.print(cust.toString());
	System.out.print(cust.getCustdetails().toString());
		session.close();
		return cust;
	}
}
