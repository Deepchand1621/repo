package handson.hibernateonetoone;

import com.hibernateonetoone.dao.CustomerDao;
import com.hibernateonetoone.entity.Customer;
import com.hibernateonetoone.entity.CustomerDetails;

public class App 
{
    public static void main( String[] args )
    {
       CustomerDao dao= new CustomerDao();
    	Customer c= new Customer("Deepchanndu","Peruru");
    	CustomerDetails cd= new CustomerDetails(23,"deepuchandu13@gmail.com","Engineer",234,"Anantapur");
    	//c.setCustdetails(cd);
    	//dao.saveCustomer(c);
    	//cd.setCust(c);
    	//dao.saveCustomerDetails(cd);
    	//dao.fetchById(1);
    	//dao.fetchByCustomerId(1);
  
    	//dao.displayCustomers();//displaying the customerdetails from customer
    	
    	dao.displayCustomersDetails();//displaying customer from customer details
    	
    }
}
